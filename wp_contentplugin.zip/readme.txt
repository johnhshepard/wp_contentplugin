=== Add To Content ===
Contributors: Emark
Donate link: http://www.trottyzone.com/donation/
Tags: add to content, add content, content, add to, add to page, add category, post, posts, pages, support, note, custom, content, add to post, ads, content, disclaimer, form, forms, signup, gesture, about me, about, media, media upload, image
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 2.0
License: GPL2 or later

Place custom content above or below every post and/or page or from a specific category.

== Description ==

This plugin allows you to add your very own custom content, before and ending of every blog post! Great for ads! Also, it allows you to choose, to add the content either above or below. You can choose which categories to Leave out or which categories for it to show on. Plus you can add the content to Pages as well. 

= Bonus Features =

1. Color picker functionality where you can change the Background Color and Text Color of the content right inside the admin panel. No need for knowledge of CSS etc.

2. Media Uploaded added, with one push of a button you can upload your images, as the custom content! Awesome!

= Features =

1. User friendly administration control panel.

2. Option to upload your own picture.

3. You can add links, wrap your content in divs, or paragraph them.

4. Your chose to pick, if your want the content to be either above or below, or just go with both :)

5. Allow the content to be seen on Pages also!

6. Added color picker, to choose which color the content Background and Text Color should look like!!!!! +++++

7. <a href="http://www.trottyzone.com/finding-out-your-category-id-number/">Documentation</a> for finding the category number.

8. Dedicated Support <a href="http://www.trottyzone.com/forums/forum/wordpress-plugins/">Forum</a> for plugin.

== Installation ==

1. Upload the entire 'add-to-content' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Enjoy! ;)

== Screenshots ==

1. Settings Menu
2. Example
3. Example 2

== Frequently Asked Questions ==

Ask your questions away at the plugin <a href="http://www.trottyzone.com/forums/forum/wordpress-plugins/">Forum</a>.


== Upgrade Notice ==

= 1.0 =
* Initial release on WordPress.org

= 2.0 =
Download fix

== Changelog ==

= 1.0 =
* Initial release on WordPress.org

= 2.0 =
Download fix